# wheel
Spinning wheel of names

Copied in large part from http://jsfiddle.net/bramp/94jP6/
